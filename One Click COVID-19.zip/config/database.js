module.exports = {
  host     : 'localhost',
  user     : 'root',
  password : 'covid',
  port     : 3306,
  database : 'covidDB'
};
